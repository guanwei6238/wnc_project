#!/usr/bin/env bash
# Runs ON THE CLIENT HOST when it is also the SERVER host (one dev machine, two NICs cabled to the Pi).
# If the server address 10.10.0.3 lived in the same network namespace as the client address 10.10.0.2, the kernel would
# deliver locally and the traffic would never cross the Pi. So the second NIC (the one cabled to IF_B) is moved into a
# network namespace and the server daemons run in there.
#   sudo bench/client/netns-server.sh up [IFACE]    NIC -> netns, address, offloads/IPv6 off, nginx/iperf3/sockperf started
#   sudo bench/client/netns-server.sh down [IFACE]  stop daemons, NIC back to the root namespace, old addresses restored
#   sudo bench/client/netns-server.sh status [IFACE]
# env: SRV_IF (default enx9c69d3241bd9), NETNS (benchsrv), SRV_ADDR (10.10.0.3/24)
# Prerequisite (once): sudo bench/server/setup-server.sh --no-units
set -euo pipefail
HERE=$(cd "$(dirname "$0")" && pwd)
SETUP="$HERE/../server/setup-server.sh"
STATE=/run/bench-netns
NS=${NETNS:-benchsrv}; SRV_ADDR=${SRV_ADDR:-10.10.0.3/24}
die()  { echo "netns-server.sh: ERROR: $*" >&2; exit 1; }
info() { echo "netns-server.sh: $*" >&2; }
usage() { sed -n '2,12p' "$0" >&2; exit 2; }

[ $# -ge 1 ] || usage
CMD=$1; shift
[ $# -le 1 ] || usage
IF=${1:-${SRV_IF:-enx9c69d3241bd9}}
case "$CMD" in up|down|status) ;; -h|--help) usage ;; *) usage ;; esac
[ "$(id -u)" -eq 0 ] || die "must run as root"
command -v ip >/dev/null 2>&1 || die "'ip' not found (apt install iproute2)"

ns_exists() { ip netns list 2>/dev/null | awk '{print $1}' | grep -qx "$NS"; }
in_ns()     { ns_exists && ip -n "$NS" link show dev "$IF" >/dev/null 2>&1; }
in_root()   { ip link show dev "$IF" >/dev/null 2>&1; }

case "$CMD" in
up)
  [ -x "$SETUP" ] || die "$SETUP not found"
  [ -s /etc/nginx/conf.d/bench.conf ] || die "nginx is not configured: run  sudo $SETUP --no-units  first"
  mkdir -p "$STATE"
  if in_ns; then
    info "$IF is already in netns $NS: re-applying the configuration and restarting the daemons"
  else
    in_root || die "no such interface: $IF (set SRV_IF or pass it as argument)"
    # remember the current IPv4 addresses (moving the NIC drops them); keep an older record if a previous 'up' died halfway
    cur=$(ip -o -4 addr show dev "$IF" | awk '{print $4}')
    if [ -n "$cur" ] || [ ! -e "$STATE/$IF.addrs" ]; then printf '%s\n' "$cur" > "$STATE/$IF.addrs"; fi
    ns_exists || ip netns add "$NS"
    ip link set "$IF" netns "$NS" || die "could not move $IF into netns $NS"
    info "$IF moved into netns $NS (it is gone from the root namespace until 'down'; previous addresses: $(tr '\n' ' ' < "$STATE/$IF.addrs"))"
  fi
  ip -n "$NS" link set lo up
  ip -n "$NS" link set "$IF" up
  ip -n "$NS" -4 addr show dev "$IF" | grep -qw "${SRV_ADDR%/*}" || ip -n "$NS" addr add "$SRV_ADDR" dev "$IF"
  ip netns exec "$NS" sysctl -qw "net.ipv6.conf.$IF.disable_ipv6=1" 2>/dev/null || info "could not disable IPv6 on $IF in $NS"
  chg=$(ip netns exec "$NS" ethtool -K "$IF" gro off lro off gso off tso off 2>&1 | tr '\n' ';' || true)
  info "ethtool -K $IF gro/lro/gso/tso off: ${chg:-no output}"
  ip netns exec "$NS" "$SETUP" --start
  cat >&2 <<MSG
netns-server.sh: server is up in netns $NS on $IF ($SRV_ADDR). The client side keeps its own address (e.g. 10.10.0.2/24 on the other NIC).
Next: run inline.sh on the Pi; 10.10.0.3 only answers while the Pi forwards (ping from here fails before that).
      Check from here during a run:  curl -s -o /dev/null -w '%{http_code}\n' http://${SRV_ADDR%/*}/1k
MSG
  ;;
down)
  if ns_exists; then
    ip netns exec "$NS" "$SETUP" --stop 2>/dev/null || true
    if in_ns; then
      ip -n "$NS" link set "$IF" netns 1 || die "could not move $IF back to the root namespace"
      info "$IF moved back to the root namespace"
    fi
    ip netns del "$NS" 2>/dev/null || true
    info "netns $NS deleted"
  else
    info "netns $NS does not exist"
  fi
  if in_root && [ -s "$STATE/$IF.addrs" ]; then
    ip link set "$IF" up
    while read -r a; do
      [ -n "$a" ] || continue
      ip -4 addr show dev "$IF" | grep -qw "${a%/*}" || ip addr add "$a" brd + dev "$IF"
    done < "$STATE/$IF.addrs"
    info "$IF: addresses restored: $(tr '\n' ' ' < "$STATE/$IF.addrs")"
    rm -f "$STATE/$IF.addrs"
  elif in_root; then
    info "$IF is in the root namespace (no recorded addresses to restore)"
  fi
  ;;
status)
  if ns_exists; then
    echo "netns $NS: exists"
    in_ns && { echo "$IF (in $NS):"; ip -n "$NS" -br addr show dev "$IF"; ip netns exec "$NS" ss -ltn 2>/dev/null | awk 'NR>1{print "  listening " $4}' | sort -u; } \
          || echo "$IF is not in $NS"
  else
    echo "netns $NS: absent"
  fi
  in_root && { echo "$IF (root namespace):"; ip -br addr show dev "$IF"; }
  [ ! -s "$STATE/$IF.addrs" ] || echo "recorded addresses for restore: $(tr '\n' ' ' < "$STATE/$IF.addrs")"
  ;;
esac

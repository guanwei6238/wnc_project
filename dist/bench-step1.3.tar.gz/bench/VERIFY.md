# Verification runbook

Step-by-step checks that a build of `bench/` works on the real hardware. One section per development step; each section is
self-contained and ends with a pass checklist. Example values are those of the current lab (dev machine `eno2`/`enx9c69d3241bd9`,
Pi `eth0`/`eth1`, user `wnc` on the Pi, user `sixsquare` on the dev machine); change them for another setup.

* [Step 1: RFC 9411 `cps`, governor restore, in-band management, ssh ControlMaster](#step-1)
* Step 2: *(placeholder, e.g. Snort 3 in management mode; copy the structure of Step 1: topology/changes, one-time setup, runs with expected output, checklist, teardown, troubleshooting)*

---

<a id="step-1"></a>
## Step 1: RFC 9411 `cps`, governor restore, in-band management, ssh ControlMaster

What this step changed, and what you are about to check:

1. `inline.sh --test cps --target-cps N` runs the RFC 9411 profile (init / ramp / sustain) with pass/fail criteria.
2. The CPU governor set by `run.sh`/`inline.sh` is restored on exit (`GOVERNOR=keep` skips it).
3. IF_A may carry a management address (`MGMT_NET`), so the Pi needs no Wi-Fi and no third NIC; engines and the bridge ignore that traffic.
4. The default `CLIENT_CMD` ssh reuses one connection (ControlMaster).
5. `bench/client/netns-server.sh`: the dev machine acts as client **and** server.

### Topology

```
 dev machine (client + server)                                   Raspberry Pi 3B+ (wnc@10.254.254.2)
 +----------------------------------------------+               +--------------------------------------+
 | root namespace = CLIENT                      |   cable 1     | eth0 = IF_A  10.254.254.2/24 (mgmt)  |
 |   eno2  10.254.254.1/24  management          |---------------| [ kernel bridge | suricata ]         |
 |         10.10.0.2/24     test (client side)  |               |                                      |
 |                                              |   cable 2     | eth1 = IF_B  (no IPv4, test only)    |
 | netns benchsrv = SERVER                      |---------------|                                      |
 |   enx9c69d3241bd9  10.10.0.3/24  (nginx :80, |               +--------------------------------------+
 |   :443, iperf3, sockperf)                    |
 +----------------------------------------------+
 test path:  10.10.0.2 -> eno2 -> Pi eth0 -> [engine] -> Pi eth1 -> enx9c69... (in netns) = 10.10.0.3
 control:    Pi (root) --ssh over IF_A--> sixsquare@10.254.254.1 runs bench/client/run-client.sh; you ssh to wnc@10.254.254.2
```

| address | where | why |
|---|---|---|
| `10.10.0.0/24` (client .2, server .3) | test subnet | what the engine inspects; `SERVER_IP` default |
| `10.254.254.0/24` (dev .1, Pi .2) | management zone on IF_A | `MGMT_NET`, derived by `inline.sh` from `eth0`'s address. Your ssh to the Pi and the Pi's ssh to the client use it; the engine/bridge must not forward it to IF_B |
| netns `benchsrv` | on the dev machine | if 10.10.0.3 lived next to 10.10.0.2 in one namespace, the kernel would deliver locally and traffic would never cross the Pi |
| none on `eth1` (IF_B) | Pi | `inline.sh` refuses to run if IF_B has an IPv4 address |

### One-time setup

**1. Deploy** (from the dev machine, in the directory that holds the tarball). An older `~/bench` may already exist on the Pi (and on the dev machine): extracting over it is fine.
Afterwards confirm the new version landed: `ls ~/bench/VERIFY.md ~/bench/client/netns-server.sh` must list both files (on the dev machine and on the Pi). Note the **colon at the end of the scp target**;
without it scp silently creates a *local file* named `wnc@10.254.254.2` instead of copying.
```sh
sha256sum -c bench-step1.3.tar.gz.sha256
tar xzf bench-step1.3.tar.gz -C ~                       # -> ~/bench  (must be ~/bench of the user the Pi ssh's into: sixsquare)
scp bench-step1.3.tar.gz bench-step1.3.tar.gz.sha256 wnc@10.254.254.2:     # <- trailing colon!
ssh wnc@10.254.254.2 'sha256sum -c bench-step1.3.tar.gz.sha256 && tar xzf bench-step1.3.tar.gz'     # -> /home/wnc/bench
```

**2. Dev machine** (client and server side):
```sh
sudo ~/bench/client/setup-client.sh                     # iperf3 sockperf nghttp2-client curl openssl iproute2 ethtool python3
sudo ~/bench/server/setup-server.sh --no-units          # nginx/objects/cert only; no systemd unit, nothing started on the host
#   (if apt had to install nginx it is stopped and disabled again; the daemons will live in the netns)
sudo ip addr del 192.168.99.2/24 dev eno2               # no longer needed (management is 10.254.254.0/24); ignore "Cannot assign" if already gone
ip -4 addr show eno2                                    # expect exactly 10.254.254.1/24 and 10.10.0.2/24
sudo ethtool -K eno2 gro off lro off gso off tso off
sudo sysctl -w net.ipv6.conf.eno2.disable_ipv6=1        # IPv6 RS/MLD chatter is not covered by the management filters
sudo ~/bench/client/netns-server.sh up                  # NIC enx9c69d3241bd9 -> netns benchsrv, 10.10.0.3/24, daemons started
sudo ~/bench/client/netns-server.sh status              # expect :80 :443 :5201 :11111 listening inside benchsrv
```
`netns-server.sh up` remembers the NIC's old address (10.254.127.1/24) and restores it on `down`. While it is up the NIC is **not visible in
the root namespace** (`ip a` will not list it; use `sudo ip netns exec benchsrv ip a`). If NetworkManager manages that NIC it
may re-apply its profile after `down`; the restore is idempotent.
If the dev machine runs a host nginx of its own, note that `setup-server.sh --start/--stop` use `/run/nginx.pid` and would stop it too; there is none on your machine today.
If the Pi's `eth0` carried `192.168.99.1/24` from the earlier instructions, remove it there too (two prefixes on IF_A abort the run):
`sudo ip addr del 192.168.99.1/24 dev eth0`.

**3. Pi:**
```sh
# The Pi is offline (no apt). ethtool/nft live in /usr/sbin, which a plain user's PATH misses, so check under sudo:
sudo sh -c 'for t in /usr/bin/time ethtool nft python3; do command -v $t || echo MISSING $t; done'
#   anything MISSING must be brought as a .deb file and installed with dpkg -i
echo "127.0.1.1 $(hostname)" | sudo tee -a /etc/hosts        # optional: stops sudo's "unable to resolve host" warning (and its DNS delay)
sudo -v                                                 # sudo asks for a password: authenticate now (repeat when it expires, default 15 min)
ip -4 addr show eth0                                    # expect only 10.254.254.2/24 (+ nothing else)
ip -4 addr show eth1                                    # expect NO inet line; if there is one: sudo ip addr flush dev eth1
# governor stuck at 'performance' from the old script? put it back (or reboot):
cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor
echo ondemand | sudo tee /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor
vcgencmd get_throttled
# root ssh key to the dev machine (inline.sh runs as root and ssh's from there)
sudo ssh-keygen -t ed25519 -N '' -f /root/.ssh/id_ed25519
sudo ssh-copy-id sixsquare@10.254.254.1
sudo ssh sixsquare@10.254.254.1 ls bench/client/run-client.sh      # must print the path, no password prompt
```
`vcgencmd get_throttled` bits: `0x0` = clean. Low nibble = *now* (bit0 under-voltage, bit1 clock capped, bit2 throttled, bit3 soft
temperature limit); bits 16-19 = the same *has occurred since boot*. Your `0xd0005` means under-voltage and throttling right now and in the
past. Performance numbers from such a run are unreliable (the firmware caps the clock whatever the governor is), but **Step 1 validates logic
(criteria, cleanup, filters), not speed**, so you can proceed. `inline.sh` prints a warning with the value at the start of every run. Fix the power supply/cable
before any real measurement. Note: `ping 10.10.0.3` from the client only works **while `inline.sh` is running** (the Pi forwards only then).

### Verification runs (on the Pi, in `~/bench`)

Common settings (tmpfs output: nothing is written to the SD card; copy the CSV off afterwards):
```sh
cd ~/bench
export CLIENT_HOST=sixsquare@10.254.254.1 SERVER_IP=10.10.0.3
RUN="sudo env CLIENT_HOST=$CLIENT_HOST SERVER_IP=$SERVER_IP ./inline.sh --ifa eth0 --ifb eth1 --out /run/bench-logs/inline.csv"
SHORT="--test cps --target-cps 200 --ramp-s 6 --sustain-s 10"
```
Keep a second terminal on the dev machine for the optional checks. Your ssh session to the Pi (over `eth0`) must stay alive through the
`none` run: that is part of what is being verified.

**Run 1: kernel-bridge baseline, short RFC cps, management mode**
```sh
$RUN --engine none $SHORT --label s1-none
```
Expect in the log, in this order: `management mode: MGMT_NET=10.254.254.0/24 derived from eth0 address(es) 10.254.254.2/24`;
`management counters: nft netdev table inline_mgmt_ctr on eth0`; `management mode: 10.254.254.2/24 moved from eth0 to br0 (MAC of eth0); nft bridge table inline_mgmt_br drops 10.254.254.0/24 toward eth1`;
`baseline: kernel bridge br0`; `RFC 9411 cps: target=200/s ramp=6s ... sustain=10s`; `management frames on eth0 during the measurement: rx N pkts ... tx M pkts`;
at the end `bridge br0 deleted`, `management address(es) back on eth0: 10.254.254.2/24`, `CPU governor restored: ...`.
Metrics: `crit_failed_txn=pass crit_rst=pass crit_rate_dev=pass crit_all=pass`, `cps_sustain_mean` about 200, `txn_failed=0`,
`rfc9411_conformant=no`, `rfc9411_deviations=sustain=10s<300s`, and `mgmt_ifa_rx_pkts/bytes`, `mgmt_ifa_tx_pkts/bytes` rows. Your ssh session stays up.
Afterwards on the Pi: `ip -br addr show eth0` has 10.254.254.2/24 again, `ip link show br0` fails, `sudo nft list tables` shows no `inline_mgmt_*`.
(Optional leak check, dev machine, during the run: `sudo ip netns exec benchsrv tcpdump -ni enx9c69d3241bd9 net 10.254.254.0/24` prints **zero** packets.)

**Run 2: Suricata, same test**
```sh
$RUN --engine suricata --rules none $SHORT --label s1-suricata
```
Expect additionally: `suricata bpf-filter 'not net 10.254.254.0/24' on both af-packet entries`, `engine ready after Ns`; the same pass metrics; the `eng_rx` figure
in the final line is the engine packet count (roughly 10 packets per connection: about 27000 for this profile including the ramp). `grep -i bpf /run/bench-logs/*/engine.out` shows Suricata's
"dropping all non matching packets" warning, which is the intent. Leak check as above: zero packets.

**Run 3: Snort 3 with management mode (stub)**
```sh
$RUN --engine snort3 --rules none $SHORT --label s1-snort
```
Expect: `ERROR: in-band management not yet verified for Snort 3 / DAQ afpacket; see README`, exit status 1, nothing changed (`ip -br addr show eth0` unchanged, no `br0`).

**Run 4: Suricata, full RFC defaults (about 6 minutes)**
```sh
$RUN --engine suricata --rules none --test cps --target-cps 200 --label s1-full
```
Expect `rfc9411_conformant=yes`, `rfc9411_deviations=none`, `init_s=5 ramp_s=30 sustain_s=300`, `crit_all=pass`, `txn_total=60000`, about 298 samples (`cps_samples`).
`CLIENT_TIMEOUT` is raised automatically (init+ramp+sustain+120 s). If `crit_*` fail on the Pi at 200/s (under-voltage), lower `--target-cps` and note it: that is a
performance finding, not a logic failure.

**Run 5: governor restore** (do not set `GOVERNOR`; default is to set `performance` and restore)
```sh
cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor                       # before, e.g. ondemand
sudo -v          # sudo needs a password: a prompt inside the backgrounded command below would hang it, so authenticate right now
$RUN --engine none --test tcp --duration 20 --label s1-gov &                    # run in background...
sleep 8; cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor              # ...during: performance
wait; cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor                 # after: the value from before
```
Expect `CPU governor set to performance (was: cpu0:ondemand ...; restored on exit)` at the start and `CPU governor restored: cpu0:ondemand ...` at the end.
`GOVERNOR=keep` instead logs `GOVERNOR=keep: CPU governor left untouched` and nothing changes (reasonable while under-voltage caps the clock anyway). Try one SIGINT too: start a run and press Ctrl-C;
the governor, `br0`, the address and the nft tables must all be restored.

**Run 6 (optional): ssh ControlMaster.** Run Run 1 twice in a row: the second `management frames on eth0 ...` line shows far fewer frames (about 21 vs about 46 in the lab; the first run
pays for the ssh handshake). `sudo ls /run/bench-ssh` shows the master socket; `sudo pkill -f 'ssh: /run/bench-ssh'` stops it.

### Reading the results
```sh
awk -F, '$7=="cps" {print $9, $3, $10, $11}' /run/bench-logs/inline.csv | grep -E 'crit_|rfc9411|mgmt_ifa|cps_sustain_mean|txn_failed'
# CSV columns: 3=engine 7=test 9=label 10=metric 11=value; the last column is the run's log directory
D=$(ls -dt /run/bench-logs/*/ | head -1); grep '^#series' ${D}client-1.out | head      # per-second connection rates; #slice/#ramp lines too
scp wnc@10.254.254.2:/run/bench-logs/inline.csv .                                 # copy off before reboot (tmpfs)
```

### Step 1 pass checklist
- [ ] Run 1 and Run 2: `crit_all=pass`, `mgmt_ifa_*` rows present, `rfc9411_conformant=no` with `sustain=10s<300s` only.
- [ ] Management-mode log lines (derived `MGMT_NET=10.254.254.0/24`, the nft/bridge line for `none`, the bpf-filter line for Suricata) appear.
- [ ] Zero `10.254.254.x` packets seen inside `benchsrv` during Runs 1 and 2; your ssh session to the Pi never dropped.
- [ ] After every run: `eth0` has its address back, no `br0`, no `inline_mgmt_*` nft tables (also after Ctrl-C).
- [ ] Run 3 prints the Snort 3 stub error and changes nothing.
- [ ] Run 4: `rfc9411_conformant=yes`, `deviations=none`.
- [ ] Run 5: governor `performance` during, original value after.
- [ ] Run 6 (optional): second run's management frame count much lower.

### Teardown
```sh
sudo ~/bench/client/netns-server.sh down          # dev machine: daemons stopped, enx9c69d3241bd9 back in the root namespace with 10.254.127.1/24, netns removed
ip -br addr show enx9c69d3241bd9                  # check the original address is back
sudo sysctl -w net.ipv6.conf.eno2.disable_ipv6=0  # only if you want IPv6 on eno2 again
sudo pkill -f 'ssh: /run/bench-ssh'               # Pi: stop the ssh master (otherwise it expires after 10 minutes)
```
Pi governor: already restored by every run; if a run was killed with SIGKILL, set it by hand (`echo ondemand | sudo tee .../scaling_governor`).
If a run was SIGKILLed during `none`: `sudo ip link del br0; sudo nft delete table bridge inline_mgmt_br; sudo nft delete table netdev inline_mgmt_ctr; sudo ip addr add 10.254.254.2/24 dev eth0`.

### Troubleshooting
| symptom | cause / fix |
|---|---|
| `client command exited with 255`, `Permission denied (publickey)` / `Host key verification failed` | root has no key on the dev machine or never accepted its host key: repeat the root ssh step and run `sudo ssh sixsquare@10.254.254.1 true` once by hand |
| `ssh: ... bench/client/run-client.sh: No such file` | `bench/` must be `~/bench` of **sixsquare** on the dev machine |
| `ERROR: eth1 has an IP address; IF_B must be an address-less test interface` | `sudo ip addr flush dev eth1` |
| `ERROR: eth0 has addresses in several prefixes ...; set MGMT_NET` | remove the extra address (e.g. 192.168.99.1/24) or `export MGMT_NET=10.254.254.0/24` |
| `ERROR: eth0 has address ... outside MGMT_NET=...` | `MGMT_NET` is set in your environment and does not match: unset it |
| `netns-server.sh: nginx is not configured` | run `sudo ~/bench/server/setup-server.sh --no-units` first |
| `netns-server.sh: no such interface: enx...` | the NIC is already in the netns (`status`) or has another name: `ip -br link`, `SRV_IF=<name>` |
| client cannot reach 10.10.0.3 during a run | `ip route get 10.10.0.3` on the dev machine must say `dev eno2`; `ip -4 addr` in the root namespace must not contain 10.10.0.3 (then it would answer locally); check that cable 2 goes to the Pi's `eth1` and `ip -br link` shows it up |
| tests fail only with Suricata and everything times out | in Docker this was veth checksum offload; **it does not apply to real NICs**. On hardware check `ethtool -k eth0 | grep checksum` and the engine log in `/run/bench-logs/*/engine.out` |
| `generator-limited` warnings | only in the UDP NDR search; not part of Step 1 |
| `vcgencmd get_throttled=0x...` warning, `crit_*` fail at 200/s | under-voltage/throttling: fix the power first; logic checks (cleanup, filters, conformance) are still valid |
| a backgrounded run (`... &`, Run 5) hangs and never starts | sudo is waiting for a password on a background process: `fg` and type it, or run `sudo -v` right before starting it |
| `sudo: unable to resolve host <name>` (and every sudo is slow) | the hostname is not in `/etc/hosts` and there is no DNS: `echo "127.0.1.1 $(hostname)" \| sudo tee -a /etc/hosts` |
| management frames counters missing | `nft` not installed or kernel lacks the egress hook (needs >= 5.16): a warning says so; the run continues |

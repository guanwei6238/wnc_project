# bench/lib.sh -- helpers shared by inline.sh and sweep-inline.sh (sourced, not executed).
# Same conventions as run.sh (which keeps its own copies): set PROG before sourcing for message prefixes.
PROG=${PROG:-bench}
die()  { echo "$PROG: ERROR: $*" >&2; exit 1; }
warn() { echo "$PROG: WARNING: $*" >&2; }
info() { echo "$PROG: $*" >&2; }

san()  { printf '%s' "$1" | tr ',\n\r"' '    ' | sed 's/^ *//;s/ *$//'; }
calc() { awk "BEGIN{printf \"%.4f\", $1}"; }
now()  { date +%s.%N; }
ro()   { local f=$1; [ -r "$f" ] && cat "$f" 2>/dev/null || true; }

HAVE_VC=0; command -v vcgencmd >/dev/null 2>&1 && HAVE_VC=1
vc_temp() { [ $HAVE_VC = 1 ] && vcgencmd measure_temp 2>/dev/null | sed -n "s/temp=\([0-9.]*\).*/\1/p" || true; }
vc_thr()  { [ $HAVE_VC = 1 ] && vcgencmd get_throttled 2>/dev/null | sed -n 's/throttled=//p' || true; }

cpu_snap() { awk '/^cpu /{idle=$5+$6; t=0; for(i=2;i<=9;i++) t+=$i; print t, idle}' /proc/stat; }
cpu_pct()  { # $1 "t i" start, $2 "t i" end
  awk -v a="$1" -v b="$2" 'BEGIN{split(a,x," ");split(b,y," ");dt=y[1]-x[1];di=y[2]-x[2]; if(dt>0) printf "%.2f",(dt-di)*100/dt}'; }

# wait until the SoC is below $1 degC (no-op without vcgencmd)
wait_temp() {
  local max=$1 t
  [ $HAVE_VC = 1 ] || return 0
  while :; do
    t=$(vc_temp); [ -z "$t" ] && return 0
    awk -v t="$t" -v m="$max" 'BEGIN{exit !(t<m)}' && return 0
    info "SoC at ${t}C, waiting for < ${max}C"; sleep 5
  done
}

# set CPU governor to performance where writable
set_governor() {
  local g cur gov_changed=""
  for g in /sys/devices/system/cpu/cpu[0-9]*/cpufreq/scaling_governor; do
    [ -w "$g" ] || continue
    cur=$(cat "$g")
    [ "$cur" = performance ] || { echo performance > "$g" 2>/dev/null && gov_changed="$gov_changed $(basename "$(dirname "$(dirname "$g")")"):$cur"; }
  done
  [ -n "$gov_changed" ] && info "CPU governor set to performance (was:$gov_changed)"
  [ "$(ro /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor)" = performance ] || \
    [ ! -e /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor ] || warn "CPU governor is not performance"
  return 0
}

# mount tmpfs on $1 unless it already is one
ensure_tmpfs() {
  local d=$1
  if ! grep -q " $d tmpfs " /proc/mounts 2>/dev/null; then
    mkdir -p "$d"
    mount -t tmpfs -o size=256M tmpfs "$d" 2>/dev/null && info "mounted tmpfs on $d" \
      || warn "could not mount tmpfs on $d; logs go to the regular filesystem (I/O may skew results)"
  fi
}

# write a snort3 bench.lua: gen_bench_lua FILE RULES(full|none)  (env HOME_NET SNORT_CONF SNORT_RULES)
gen_bench_lua() {
  local f=$1 rules=$2
  {
    echo "include '$SNORT_CONF'"
    echo "HOME_NET = '$HOME_NET'"
    echo "EXTERNAL_NET = '!\$HOME_NET'"
    echo "for k, v in pairs(ips.variables.nets) do if v == 'any' then ips.variables.nets[k] = HOME_NET end end"
    echo "ips.variables.nets.HOME_NET = HOME_NET"
    echo "ips.variables.nets.EXTERNAL_NET = EXTERNAL_NET"
    if [ "$rules" = full ]; then
      [ -r "$SNORT_RULES" ] || die "snort rules file not found: $SNORT_RULES"
      echo "ips.rules = [[ include $SNORT_RULES ]]"
    else
      echo "ips.rules = nil"
    fi
  } > "$f"
}

# suricata: print the "outputs.N.xxx.enabled" keys that are on in the config, one per line
suricata_outputs_off_keys() { # $1 binary $2 conf
  "$1" -c "$2" --dump-config 2>/dev/null \
    | sed -n 's/^\(outputs\.[0-9]*\.\(fast\|eve-log\|syslog\|http-log\|tls-log\|lua\|file-store\|tcp-data\|http-body-data\|pcap-log\|alert-debug\|tls-store\)\.enabled\) = yes$/\1/p'
}
